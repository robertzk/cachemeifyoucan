library(testthat)
library("cachemeifyoucan")
test_check("cachemeifyoucan")
